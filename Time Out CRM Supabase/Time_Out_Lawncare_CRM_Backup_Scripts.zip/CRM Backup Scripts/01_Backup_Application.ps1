$ErrorActionPreference = "Stop"

$SourcePath = "C:\Users\Dee Dee\Documents\Time Out Lawncare CRM"
$BackupPath = "L:\Time Out Lawncare CRM Backups"

if (-not (Test-Path -LiteralPath $SourcePath -PathType Container)) {
    throw "Application folder was not found: $SourcePath"
}

if (-not (Test-Path -LiteralPath "L:\" -PathType Container)) {
    throw "Backup drive L: is not available. Connect the drive and try again."
}

New-Item -ItemType Directory -Path $BackupPath -Force | Out-Null

$Timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
$Destination = Join-Path $BackupPath "Time_Out_Lawncare_CRM_App_$Timestamp.zip"
$SourcePrefix = $SourcePath.TrimEnd("\") + "\"

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$Archive = [System.IO.Compression.ZipFile]::Open(
    $Destination,
    [System.IO.Compression.ZipArchiveMode]::Create
)

$IncludedFiles = 0

try {
    Get-ChildItem -LiteralPath $SourcePath -File -Recurse -Force |
        ForEach-Object {
            $RelativePath = $_.FullName.Substring($SourcePrefix.Length)
            $PathParts = $RelativePath -split "\\"
            $Extension = $_.Extension.ToLowerInvariant()
            $LeafName = $_.Name.ToLowerInvariant()

            $ExcludedFolder = (
                $PathParts -contains ".git" -or
                $PathParts -contains "venv" -or
                $PathParts -contains ".venv" -or
                $PathParts -contains "__pycache__"
            )

            $ExcludedFile = (
                $RelativePath -ieq ".streamlit\secrets.toml" -or
                $Extension -in @(
                    ".pyc",
                    ".db",
                    ".sqlite",
                    ".sqlite3",
                    ".xlsx",
                    ".xls",
                    ".xlsm",
                    ".log",
                    ".zip"
                ) -or
                $LeafName -in @(
                    "geo_cache.json",
                    "geocode_cache.json",
                    "last_dispatch.json",
                    "notes.txt"
                ) -or
                $LeafName.StartsWith("temp_")
            )

            if (-not $ExcludedFolder -and -not $ExcludedFile) {
                $ZipPath = $RelativePath.Replace("\", "/")

                [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile(
                    $Archive,
                    $_.FullName,
                    $ZipPath,
                    [System.IO.Compression.CompressionLevel]::Optimal
                ) | Out-Null

                $IncludedFiles++
            }
        }
}
catch {
    $Archive.Dispose()

    if (Test-Path -LiteralPath $Destination) {
        Remove-Item -LiteralPath $Destination -Force
    }

    throw
}
finally {
    if ($null -ne $Archive) {
        $Archive.Dispose()
    }
}

if ($IncludedFiles -eq 0) {
    if (Test-Path -LiteralPath $Destination) {
        Remove-Item -LiteralPath $Destination -Force
    }

    throw "No application files were added to the backup."
}

$VerificationArchive = [System.IO.Compression.ZipFile]::OpenRead($Destination)

try {
    if ($VerificationArchive.Entries.Count -ne $IncludedFiles) {
        throw "Application backup verification failed."
    }
}
finally {
    $VerificationArchive.Dispose()
}

Write-Host ""
Write-Host "Application backup completed successfully."
Write-Host "Files backed up: $IncludedFiles"
Write-Host "Backup file: $Destination"

