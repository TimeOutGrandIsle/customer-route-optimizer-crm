param(
    [string]$RunTime = "19:00"
)

$ErrorActionPreference = "Stop"

$TaskName = "Time Out Lawncare CRM Daily Backup"
$ScriptFolder = Split-Path -Parent $MyInvocation.MyCommand.Path
$Runner = Join-Path $ScriptFolder "03_Run_All_Backups.ps1"

if (-not (Test-Path -LiteralPath $Runner -PathType Leaf)) {
    throw "Combined backup runner was not found: $Runner"
}

try {
    $ParsedTime = [datetime]::ParseExact(
        $RunTime,
        "HH:mm",
        [System.Globalization.CultureInfo]::InvariantCulture
    )
}
catch {
    throw "RunTime must use 24-hour HH:mm format, for example 19:00."
}

$PowerShellArguments = (
    '-NoProfile -ExecutionPolicy Bypass -File "' +
    $Runner +
    '"'
)

$Action = New-ScheduledTaskAction `
    -Execute "powershell.exe" `
    -Argument $PowerShellArguments

$Trigger = New-ScheduledTaskTrigger `
    -Daily `
    -At $ParsedTime

$Settings = New-ScheduledTaskSettingsSet `
    -StartWhenAvailable `
    -ExecutionTimeLimit (New-TimeSpan -Hours 2)

$UserId = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name

$Principal = New-ScheduledTaskPrincipal `
    -UserId $UserId `
    -LogonType Interactive `
    -RunLevel Limited

Register-ScheduledTask `
    -TaskName $TaskName `
    -Action $Action `
    -Trigger $Trigger `
    -Settings $Settings `
    -Principal $Principal `
    -Description "Backs up the Time Out Lawncare CRM application and Supabase database." `
    -Force | Out-Null

Write-Host ""
Write-Host "Scheduled task installed successfully."
Write-Host "Task: $TaskName"
Write-Host "Schedule: Daily at $RunTime"
Write-Host "The task runs when Dee Dee is logged in and starts later if the scheduled time was missed."

