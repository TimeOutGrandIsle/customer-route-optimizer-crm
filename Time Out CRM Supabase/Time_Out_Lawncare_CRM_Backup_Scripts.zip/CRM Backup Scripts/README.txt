TIME OUT LAWNCARE CRM BACKUP KIT
================================

Configured paths
----------------

Working application:
C:\Users\Dee Dee\Documents\Time Out Lawncare CRM

Application backups:
L:\Time Out Lawncare CRM Backups

Database backups:
L:\Time Out Lawncare CRM Database Backups


ONE-TIME INSTALLATION
---------------------

1. Copy the entire "CRM Backup Scripts" folder into:

   C:\Users\Dee Dee\Documents\Time Out Lawncare CRM

2. Confirm this file exists:

   C:\Users\Dee Dee\Documents\Time Out Lawncare CRM\.streamlit\secrets.toml

3. Confirm secrets.toml contains the working [postgres] section.

4. Confirm drive L: is connected.


MANUAL TEST -- RUN THESE IN ORDER
---------------------------------

Open PowerShell and run:

cd "C:\Users\Dee Dee\Documents\Time Out Lawncare CRM\CRM Backup Scripts"

PowerShell -NoProfile -ExecutionPolicy Bypass -File ".\01_Backup_Application.ps1"

Confirm a new application ZIP appears in:

L:\Time Out Lawncare CRM Backups

Next run:

PowerShell -NoProfile -ExecutionPolicy Bypass -File ".\02_Backup_Database.ps1"

Confirm a new database ZIP appears in:

L:\Time Out Lawncare CRM Database Backups

Next test the combined runner:

PowerShell -NoProfile -ExecutionPolicy Bypass -File ".\03_Run_All_Backups.ps1"

Confirm that both new ZIP files were created and that a log appears in:

L:\Time Out Lawncare CRM Backups\Logs


INSTALL THE DAILY SCHEDULE
--------------------------

The default installation runs both backups every day at 7:00 PM.

PowerShell -NoProfile -ExecutionPolicy Bypass -File ".\04_Install_Daily_Backup_Task.ps1"

To select a different time, use 24-hour HH:mm format. Example for 8:30 PM:

PowerShell -NoProfile -ExecutionPolicy Bypass -File ".\04_Install_Daily_Backup_Task.ps1" -RunTime "20:30"

The installer replaces the existing task if it is run again.


VERIFY THE SCHEDULE
-------------------

Open Task Scheduler and locate:

Time Out Lawncare CRM Daily Backup

Right-click the task and select Run.

Confirm that both backup locations receive a new ZIP and review the newest log.


IMPORTANT
---------

The scheduled task runs under the current Windows account and uses the mapped
L: drive. Dee Dee must be logged in, and L: must be connected.

Application ZIPs intentionally exclude:

- .streamlit\secrets.toml
- Git internals
- virtual environments
- SQLite files
- customer spreadsheets
- generated caches and logs

Store the Supabase and Google credentials separately in a password manager or
another encrypted location.
