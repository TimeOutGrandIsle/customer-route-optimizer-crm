$ErrorActionPreference = "Stop"

$WorkingPath = "C:\Users\Dee Dee\Documents\Time Out Lawncare CRM"
$BackupPath = "L:\Time Out Lawncare CRM Database Backups"
$BackupProgram = Join-Path $WorkingPath "backup_database.py"
$SecretsFile = Join-Path $WorkingPath ".streamlit\secrets.toml"

if (-not (Test-Path -LiteralPath $WorkingPath -PathType Container)) {
    throw "Application folder was not found: $WorkingPath"
}

if (-not (Test-Path -LiteralPath $BackupProgram -PathType Leaf)) {
    throw "Database backup program was not found: $BackupProgram"
}

if (-not (Test-Path -LiteralPath $SecretsFile -PathType Leaf)) {
    throw "Local Streamlit secrets file was not found: $SecretsFile"
}

if (-not (Select-String -LiteralPath $SecretsFile -Pattern "^\s*\[postgres\]\s*$" -Quiet)) {
    throw "The local secrets file has no [postgres] section."
}

if (-not (Test-Path -LiteralPath "L:\" -PathType Container)) {
    throw "Backup drive L: is not available. Connect the drive and try again."
}

if ($null -eq (Get-Command python -ErrorAction SilentlyContinue)) {
    throw "Python was not found on PATH."
}

New-Item -ItemType Directory -Path $BackupPath -Force | Out-Null

$StartedAt = Get-Date

Push-Location $WorkingPath

try {
    & python $BackupProgram $BackupPath

    if ($LASTEXITCODE -ne 0) {
        throw "backup_database.py exited with code $LASTEXITCODE."
    }
}
finally {
    Pop-Location
}

$BackupFile = Get-ChildItem -LiteralPath $BackupPath -File -Filter "timeoutcrm_postgres_*.zip" |
    Where-Object { $_.LastWriteTime -ge $StartedAt.AddSeconds(-2) } |
    Sort-Object LastWriteTime -Descending |
    Select-Object -First 1

if ($null -eq $BackupFile) {
    throw "No new PostgreSQL backup ZIP was found after the backup completed."
}

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$VerificationArchive = [System.IO.Compression.ZipFile]::OpenRead($BackupFile.FullName)

try {
    $EntryNames = @($VerificationArchive.Entries | ForEach-Object { $_.FullName })

    if ($EntryNames.Count -eq 0) {
        throw "The database backup ZIP is empty."
    }

    if ($EntryNames -notcontains "customers.csv") {
        throw "The database backup does not contain customers.csv."
    }
}
finally {
    $VerificationArchive.Dispose()
}

Write-Host ""
Write-Host "Database backup completed and verified successfully."
Write-Host "Tables exported: $($EntryNames.Count)"
Write-Host "Backup file: $($BackupFile.FullName)"

