$ErrorActionPreference = "Stop"

$ScriptFolder = Split-Path -Parent $MyInvocation.MyCommand.Path
$ApplicationBackup = Join-Path $ScriptFolder "01_Backup_Application.ps1"
$DatabaseBackup = Join-Path $ScriptFolder "02_Backup_Database.ps1"
$LogFolder = "L:\Time Out Lawncare CRM Backups\Logs"

if (-not (Test-Path -LiteralPath "L:\" -PathType Container)) {
    throw "Backup drive L: is not available. Connect the drive and try again."
}

New-Item -ItemType Directory -Path $LogFolder -Force | Out-Null

$Timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
$LogFile = Join-Path $LogFolder "CRM_Backup_$Timestamp.log"

Start-Transcript -Path $LogFile -Force | Out-Null

try {
    Write-Host "Time Out Lawncare CRM backup started: $(Get-Date)"
    Write-Host ""
    Write-Host "Step 1 of 2: Application backup"

    & $ApplicationBackup

    Write-Host ""
    Write-Host "Step 2 of 2: Database backup"

    & $DatabaseBackup

    Write-Host ""
    Write-Host "All backups completed successfully: $(Get-Date)"
}
catch {
    Write-Error "CRM backup failed: $($_.Exception.Message)"
    throw
}
finally {
    Stop-Transcript | Out-Null
}

